<html>
<head>
<title>LOGIN</title>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>

<body>
<div class="header"><img src="header.png" width="100%" height="20%"></div>
<h1 align="center">LOGIN FORM</h1>
<div class="container">
<div class="containerleft">
</div>
<div class="containerright">

<form method="post" action="">
username:<input type="text" name="username"><br />
password:<input type="password" name="password"><br />
<input type="submit" name="submit" value="login"><br /><br />
<input type="reset" name="cancel" value="cancel"><br /><br />
<a href="../home/Recover.php">Account Recovery</a>
</form>
<a href="../index.html"><button>BACK</button></a>
</div>
</div>
</body>


<?Php 
error_reporting (E_ALL^E_NOTICE);
     
if (isset($_POST['submit'])){
	
	$un=$_POST['username'];
	$p=$_POST['password'];
	
	
	

		$conn = mysqli_connect("localhost","root","","cs_2001") or die("unsucessful");
		$s= "SELECT * FROM login WHERE USERNAME= '$un' && PASSWORD='$p' "; 
        $result=mysqli_query($conn,$s);
		if (!($result)||  mysqli_num_rows($result)==0){
			echo "<script>alert('Acess denied!')</script>";
			
		}
			else if (mysqli_fetch_assoc($result)["TYPE"] == 'USER'){
			$se= "UPDATE login SET TIME_STAMP=CURRENT_TIMESTAMP() WHERE USERNAME= '$un' && PASSWORD='$p' ";
			
            			
			$sec=mysqli_query($conn,$se);
			
				
			header ("location:../home/HomeMan.html");
			
			exit();
			}
			else {
				$se= "UPDATE login SET TIME_STAMP=CURRENT_TIMESTAMP() WHERE USERNAME= '$un' && PASSWORD='$p' ";
			
            			
			    $sec=mysqli_query($conn,$se);
				header ("location:../home/HomeAdmin.html");
			
			exit();
			}
			mysqli_close($conn);
	}



	
	
?>
</html>