<html>
<head>
<title>Registratration form</title>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

<div class="header"><img src="header.png" width="100%" height="20%"></div>
<h1 align="center">REGISTRATION FORM</h1>
<div class="container">
<div class="containerleft">
</div>
<div class="containerright">

<form method="post" action="registration.php">
Account:<br />
<input type="radio" name="account" value="ADMIN"/>ADMIN
<input type="radio" name="account" value="USER"/>USER<br />
Name:<input type="text" name="name"><br />
Email:<input type="email" name="email"><br />
Username:<input type="text" name="username"><br />
Secret code:<input type="text" name="secretcode"><br />
Password:<input type="password" name="password" ><br />
Confirm Password:<input type="password" name="confirmpassword"><br />
<input type="submit" name="submit" value="signup">
<input type="reset" name="cancel" value="cancel">

</form>
<a href="../index.html"><button>BACK</button></a>
</div>

</div>

</body>
<?Php 
error_reporting (E_ALL^E_NOTICE);
     


if (isset($_POST['submit'])){
	$un=$_POST['username'];
	$p=$_POST['password'];
	$n=$_POST['name'];
	$account=$_POST['account'];
	$email=$_POST['email'];
	$secret=$_POST['secretcode'];
	$confirm=$_POST['confirmpassword'];
	
	$conn = mysqli_connect("localhost","root","","cs_2001") or die("unsucessful");
		$sel="SELECT * FROM login WHERE USERNAME='$un' && TYPE='$account' && SECRET_CODE!='$secret'";
		$sec="SELECT * FROM login WHERE SECRET_CODE='$secret'";
		$s= "INSERT INTO login VALUES ('$n','$email','$account','$un','$p','$secret',CURRENT_TIMESTAMP())"; 
	
	if (strlen($p)<2){
		echo "<script>alert('Password must contain at least 3 characters!')</script>";
		
	}
	else if ($confirm != $p){
		echo "<script>alert('please confirm your password correctly!')</script>";
	}
		
		
		else if ( mysqli_num_rows(mysqli_query($conn,$sel))==1){
			echo "<script>alert('Username already taken, please select another username!')</script>";
		}
		else if (mysqli_num_rows(mysqli_query($conn,$sec))==1){
			echo "<script>alert('Please enter your unique secret code!')</script>";
		}
		else if ( !(mysqli_query($conn,$s))){
			echo "<script>alert('UNSUCESS!')</script>";
		}
		
		else{
			echo "<script>alert('SUCESS!')</script>";
			}
			mysqli_close($conn);
	}

	
	
?>
</html>