<html>
 <head>
  <title>Account Recovery</title>
  <link rel="stylesheet" type="text/css" href="ProjectStyle.css">
 </head>
 <body background="pic2.png">
 <div class="header">
 <img src="header.png" width="100%" height="20%">  
</div>
  <div class="fs">
  <form method="post" action=""> 
   <fieldset > 
    <legend> <font size="5"> <b>Recovery Details</b> </font> </legend> <br />
	 Username: <input type="text" name="un" size="20%"> <br /> <br />
	 Secret Code: <input type="password" name="sc" size="20%"> <br /> <br />
	</fieldset>
	<p  align="center"> <input type="Submit" value="Submit" name="sub">
	<input type="Reset" value="Cancel"> </p> 
	

<?php
 error_reporting (E_ALL^E_NOTICE);
 
 if (isset($_POST['sub'])) {
	 $un=$_POST['un'];
	 $sc=$_POST ['sc'];
	 
	  $conn=mysqli_connect("localhost", "root", "", "cs_2001") or die("Unsuccessful");
	  $x="SELECT PASSWORD FROM login WHERE USERNAME='$un'&& SECRET_CODE='$sc'";
	  
	  $result=mysqli_query($conn,$x);
	  if (!($result)||mysqli_num_rows($result)==0) {
		echo "<script>alert('Please enter valid details')</script>";
	  }
      else {
        echo "<b><mark>Your password is ".mysqli_fetch_assoc($result)["PASSWORD"].".</b></mark>";
	  }
 }  
?>

 
  <div align="center">
   <a href="../access/login.php" style="text-decoration:none;"> <h2>Sign In </h2></a>
    </div>
  
  
  </form>
  </div>
  
 </body>
</html> 