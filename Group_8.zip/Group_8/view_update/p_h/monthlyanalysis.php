<html>
  <head>
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/styles.css">
	<style>
	 body{
		 background-image:url('../images/financial-analysis-minimal-wallpaper-success-elements-internet-investment-financial-web-analysis-strategy-symbol-vector-108735432.jpg')
		
	 }
    



    </style>
    
 </head>
 


<body bgcolor="#CCC999">

  <br />
    <h1 align="center"><mark style="background-color:crimson;">MONTHLY ANALYSIS </mark></h1>
	<a href="../../user_view/manpage.html" target='_top'><font size=6 ><mark>&#8617;Back</mark></font></a>
      <table   cellpadding=20px align ="center">
      <tr bgcolor="#99999C">
      

<td >
    <form action="analysisresult.php" method="post">
    <div align="center">
	

<table class="t3" border=1 >
<tr>
<td><b>CODE NO</b></td>
<td><input type="text" name="code" style="width:100%;" required   /></td>
</tr>
<tr>
<td><b>MONTH</b></td>
<td><input type="month" name="m" style="width:100%;" required  /></td>
</tr>

</table>
<br/><input type="submit"  value="SEARCH" name="search"/>  
</form>
<form action="">
<input type="SUBMIT" value="CANCEL" />
</form>

               </form>
          </td>
          </tr>
		</table>
	  </div>
  </body>
</html>

  




