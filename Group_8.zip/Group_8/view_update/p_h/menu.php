<html>
<head>

<title>SPLASH</title>




<frameset rows="130px,*,10px" border="0">
<frame name="top" src="topim.html" scrolling="no" marginwidth="0" marginheight="0" frameborder="5" noresize />
<frameset cols="200,*" border="0">
<frame name="left" src="navi.html" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" noresize />
<frame  name="main" src="main.html" scrolling="auto" marginwidth="0" marginheight="0" frameborder="5" noresize />
</framest>
<frame  name="footer" src="" scrolling="no" marginwidth="0" marginheight="0" frameborder="5" noresize />
</framest>




</head>


<body>









</body>
</html>