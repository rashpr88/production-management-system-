<html>
<head>
<title>Production Details FJ DP</title>
<link rel="stylesheet" type="text/css" href="../CSS/search.css">
</head>

<body bgcolor="#00001a">

<div class="head">
</div> 

<div class="top">
<h1>Daily Production </h1>
<h2>Fruit Juices</h2></div>
<div class="bottom">

<form action="" method="post">

<div id="date">
<p>MF Date &#9002;</p>
<input type="date" name="date" id="day"></div>
</br></br></br></br></br></br></br></br>
<div name="order" align="center">
<input type="submit" id="submit" name="submit"value="Submit">
<input type="reset" id="reset" name="reset"value="Cancel">

<?php
error_reporting (E_ALL^E_NOTICE);  
if (isset($_POST['submit'])){
    
        
		
		$date=$_POST['date'];
		$d=date_create("$date");
        $n= date_format($d,"n");
		$conn = mysqli_connect("localhost","root","","cs_2001") or die("ERROR");
        
		 
        
		if ($n==1){
        $s= "SELECT jan.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM jan INNER JOIN products ON jan.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==2){
        $s= "SELECT feb.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM feb INNER JOIN products ON feb.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==3){
        $s= "SELECT mar.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM mar INNER JOIN products ON mar.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==4){
        $s= "SELECT apr.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM apr INNER JOIN products ON apr.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==5){
        $s= "SELECT may.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM may INNER JOIN products ON may.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==6){
        $s= "SELECT jun.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM jun INNER JOIN products ON jun.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==7){
        $s= "SELECT jul.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM jul INNER JOIN products ON jul.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==8){
        $s= "SELECT aug.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM aug INNER JOIN products ON aug.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==9){
        $s= "SELECT sep.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM sep INNER JOIN products ON sep.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==10){
        $s= "SELECT oct.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM oct INNER JOIN products ON oct.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		elseif ($n==11){
        $s= "SELECT nov.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM nov INNER JOIN products ON nov.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
		
		}
		else{
		$s= "SELECT de.CODE_NO,QUANTITY, MF,EXP,REJECTED,NAME FROM de INNER JOIN products ON de.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' && MF='$date'";
			
		}
        $res=mysqli_query($conn,$s);
        if (!($res) || mysqli_num_rows($res)==0){
	     echo "<script>alert('NO RECORD')</script>";
        }	    
		else {
        echo "<br><br><br>";	
        echo "<table class='t2' border=2 style='background-color:white'>";
		
		echo "<br><b style='color:white'>No.of records:". mysqli_num_rows($res);
		echo "</b>";
        for($fld=0; $fld < mysqli_num_fields($res); $fld++){
	        $f=mysqli_fetch_field_direct($res,$fld);
	        $name=$f->name;
	        echo "<th>";
	        echo "&nbsp;&nbsp;".$name; 
	        echo "</th>"; 
        }
	    while($row = mysqli_fetch_assoc($res)){
	        echo "<tr>"; 
	        echo "<td>".$row["CODE_NO"]."</td> <td>".$row["QUANTITY"]."</td> <td>".$row["MF"]."</td> <td>".$row["EXP"]."</td> <td>".$row["REJECTED"]."</td> <td>"
	        .$row["NAME"]."</td> ";
            echo "</tr>";  
	    }
	    echo "</table>";
        }
	 mysqli_close($conn);
		}
?>
</div>
</form></div>
</body>
</html>