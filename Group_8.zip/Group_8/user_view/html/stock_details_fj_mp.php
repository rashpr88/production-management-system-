<html>
<head>
<title>Stock Details FD MS</title>
<link rel="stylesheet" type="text/css" href="../CSS/search.css">
</head>

<body bgcolor="#00001a">

<div class="head">
</div> 

<div class="top">
<h1>Monthly Stock</h1>
<h2>Fruit Juices</h2></div>
<div class="bottom">

<form action="" method="post">

<div id="date">
<p>Month &#9002;</p>
<input type="month" name="month" id="day"></div>
</br></br></br></br></br></br></br></br>
<div name="order" align="center">
<input type="submit" id="submit" name="submit"value="Submit">
<input type="reset" id="reset" name="reset"value="Cancel">

<?php
	error_reporting (E_ALL^E_NOTICE);
     
     if(isset($_POST['submit'])){//get the sub command from form
		 
         $month=$_POST['month'];//get month
		$d=date_create("$month");//set month as date
        $n= date_format($d,"m");//get the month numerically
		$m= date_format($d,"F");
		$conn = mysqli_connect("localhost","root","","cs_2001") or die("ERROR");//connect to database
         
		 
        
		if ($n==1){
        $s= "SELECT jan.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM jan INNER JOIN products ON jan.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY jan.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		}
		elseif ($n==2){
        $s= "SELECT feb.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM feb INNER JOIN products ON feb.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY feb.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==3){
        $s= "SELECT mar.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM mar INNER JOIN products ON mar.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY mar.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==4){
        $s= "SELECT apr.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM apr INNER JOIN products ON apr.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY apr.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==5){
        $s= "SELECT may.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM may INNER JOIN products ON may.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY may.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==6){
        $s= "SELECT jun.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM jun INNER JOIN products ON jun.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY jun.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==7){
        $s= "SELECT jul.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM jul INNER JOIN products ON jul.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY jul.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==8){
        $s= "SELECT aug.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM aug INNER JOIN products ON aug.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY aug.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==9){
        $s= "SELECT sep.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM sep INNER JOIN products ON sep.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY sep.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		}
		elseif ($n==10){
        $s= "SELECT oct.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM oct INNER JOIN products ON oct.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY oct.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		elseif ($n==11){
        $s= "SELECT nov.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM nov INNER JOIN products ON nov.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY nov.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
		
		}
		else{
			$s= "SELECT de.CODE_NO,NAME,TYPE,SUM(QUANTITY) AS TOTAL_QUANTITY,SUM(REJECTED) AS TOTAL_REJECTED,SUM(RETRIEVED)AS TOTAL_RETRIEVED, SUM(QUANTITY)-(SUM(REJECTED)+SUM(RETRIEVED)) AS TOTAL_IN_STOCK FROM de INNER JOIN products ON de.CODE_NO=products.CODE_NO WHERE TYPE='FRUIT' GROUP BY de.CODE_NO HAVING MAX(MF)!='2018-01-01' " ;
		
			
		}
        $result=mysqli_query($conn,$s);
		if (!($result) || mysqli_num_rows($result)==0){
			echo "<script> alert('NO RECORDS ON THAT MONTH!')</script>";
		}
		else
		{
        echo "<table border=5 style='background-color:white'>";
		echo "<br>";
		echo "<br><br><br><font color='white' size=4><b><u>STOCK DETAILS FOR THE MONTH</u>:". $m;
		echo "</b></font>";
		echo "<br><b style='color:white'>No.of records:". mysqli_num_rows($result);
		echo "</b>"; //get fields to the table 
        for($fld=0; $fld < mysqli_num_fields($result); $fld++){
	        $f=mysqli_fetch_field_direct($result,$fld);
	        $name=$f->name;
	        echo "<th >";
	        echo "&nbsp;&nbsp;".$name; 
	        echo "</th>"; 
        }
	    while($row = mysqli_fetch_assoc($result)){
	        echo "<tr>"; 
	        echo "<td  >".$row["CODE_NO"]."</td> <td>".$row["NAME"]."</td> <td>".$row["TYPE"]."</td> <td>".$row["TOTAL_QUANTITY"]."</td> <td>".$row["TOTAL_REJECTED"]."</td> <td>".$row["TOTAL_RETRIEVED"]."</td> <td>"
	        .$row["TOTAL_IN_STOCK"]."</td> ";
            echo "</tr>";  
	    }
	    echo "</table>";
        }
	
    }
	
	mysqli_close($conn);
	
	
		 ?>	  
</div>
</form></div>
</body>
</html>