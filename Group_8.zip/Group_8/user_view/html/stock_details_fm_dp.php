<html>
<head>
<title>Stock Details FD DS</title>
<link rel="stylesheet" type="text/css" href="../CSS/search.css">
</head>

<body bgcolor="#00001a">

<div class="head">
</div> 

<div class="top">
<h1>Daily Stock </h1>
<h2>Flavoured Milk</h2></div>
<div class="bottom">

<form action="" method="post">

<div id="date">
<p>MF Date&#9002;</p>
<input type="date" name="date" id="day"></div>
</br></br></br></br></br></br></br></br>
<div name="order" align="center">
<input type="submit" id="submit" name="submit"value="Submit">
<input type="reset" id="reset" name="reset"value="Cancel">

<?php
error_reporting (E_ALL^E_NOTICE);  
if (isset($_POST['submit'])){
    
        $id=$_POST['code_num'];
		
		$date=$_POST['date'];
		$d=date_create("$date");
        $n= date_format($d,"n");
		$conn = mysqli_connect("localhost","root","","cs_2001") or die("ERROR");
        
		 
        
		if ($n==1){
        $s= "SELECT jan.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM jan INNER JOIN products ON products.CODE_NO=jan.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==2){
       $s= "SELECT feb.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM feb INNER JOIN products ON products.CODE_NO=feb.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==3){
        $s= "SELECT mar.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM mar INNER JOIN products ON products.CODE_NO=mar.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==4){
       $s= "SELECT apr.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM apr INNER JOIN products ON products.CODE_NO=apr.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==5){
       $s= "SELECT may.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM may INNER JOIN products ON products.CODE_NO=may.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==6){
        $s= "SELECT jun.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM jun INNER JOIN products ON products.CODE_NO=jun.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==7){
        $s= "SELECT jul.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM jul INNER JOIN products ON products.CODE_NO=jul.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==8){
        $s= "SELECT aug.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM aug INNER JOIN products ON products.CODE_NO=aug.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==9){
        $s= "SELECT sep.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM sep INNER JOIN products ON products.CODE_NO=sep.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==10){
        $s= "SELECT oct.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM oct INNER JOIN products ON products.CODE_NO=oct.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		elseif ($n==11){
        $s= "SELECT nov.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM nov INNER JOIN products ON products.CODE_NO=nov.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
		
		}
		else{
		$s= "SELECT de.CODE_NO,NAME,QUANTITY,REJECTED,RETRIEVED,IN_STOCK AS TOTAL_IN_STOCK FROM de INNER JOIN products ON products.CODE_NO=de.CODE_NO WHERE  TYPE='FLAVOURED' && MF='$date'   ";
			
		}
        $res=mysqli_query($conn,$s);
        if (!($res) || mysqli_num_rows($res)==0){
	     echo "<script>alert('NO RECORD')</script>";
        }	    
		else {
        echo "<br><br><br>";	
        echo "<table class='t2' border=2 style='background-color:white'>";
		
		echo "<br><b style='color:white'>No.of records:". mysqli_num_rows($res);
		echo "</b>";
        for($fld=0; $fld < mysqli_num_fields($res); $fld++){
	        $f=mysqli_fetch_field_direct($res,$fld);
	        $name=$f->name;
	        echo "<th>";
	        echo "&nbsp;&nbsp;".$name; 
	        echo "</th>"; 
        }
	    while($row = mysqli_fetch_assoc($res)){
	        echo "<tr>"; 
	        echo "<td>".$row["CODE_NO"]."</td> <td>".$row["NAME"]."</td> <td>".$row["QUANTITY"]."<td>".$row["REJECTED"]."<td>".$row["RETRIEVED"]."<td>".$row["TOTAL_IN_STOCK"]."</td>";
            echo "</tr>";  
	    }
	    echo "</table>";
        }
	 mysqli_close($conn);
		}
?>
</div>
</form></div>
</body>
</html>