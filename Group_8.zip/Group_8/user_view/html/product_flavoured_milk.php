<html>
<head>
<title>Product Details FM</title>
<link rel="stylesheet" type="text/css" href="../CSS/search.css">
</head>

<body bgcolor="#00001a">

<div class="head">
</div> 

<div class="top">
<h1>Product Details</h1>
<h2>Flavoured Milk</h2></div>
<div class="bottom"></br>


<form action="" method="post">

<div name="order" align="center">
<input type="submit" id="product_code_num" name="sub" value="Search">

<?php
	error_reporting (E_ALL^E_NOTICE);
     $conn = mysqli_connect("localhost","root","","cs_2001") or die("unsucessful");
     if(isset($_POST['sub'])){
	    
        
        $s= "SELECT * FROM products WHERE  TYPE='FLAVOURED MILK' "; 
        $result=mysqli_query($conn,$s);
		if (!($result) || mysqli_num_rows($result)==0){
			echo "<script> alert('NO RECORDS !')</script>";
		}
		else {
        echo "<br><br><br>";	
        echo "<table class='t2' border=2 style='background-color:white'>";
		
		echo "<br><b style='color:white'>No.of records:". mysqli_num_rows($result);
		echo "</b>";
        for($fld=0; $fld < mysqli_num_fields($result); $fld++){
	        $f=mysqli_fetch_field_direct($result,$fld);
	        $name=$f->name;
	        echo "<th>";
	        echo "&nbsp;&nbsp;".$name; 
	        echo "</th>"; 
        }
	    while($row = mysqli_fetch_assoc($result)){
	        echo "<tr>"; 
	        echo "<td>".$row["CODE_NO"]."</td> <td>".$row["NAME"]."</td> <td>".$row["TYPE"]."</td> <td>"
	        .$row["VOLUME"]."</td> ";
            echo "</tr>";  
	    }
	    echo "</table>";
        }
	
    }
	
	mysqli_close($conn);
		 ?>
</div>
</form></div>



</body>
</html>