<html>
<head>
<title>Search</title>
<link rel="stylesheet" type="text/css" href="./CSS/search_main.css">

</head>
<body bgcolor="#00001a">

<div class="head">
<img src="./image/header.png" width="1330px" height="112px">
</div>
<div class="nav">
<ul>
<li><a href="../view_update/p_h/username_password.html"> Account Settings</a></li>
<li><a href="../home/HomeMan.html">Home</a></li>
<li><a href="index.html">Activity</a></li>
<li><a href="../index.html" onclick="return logout()">Log Out</a></li> 
  <script>
  function logout(){
    var logout=confirm("Are you sure you want to log out?");
      if(logout){
         return true;
        }
      else{
         return false;
        }
    }
  </script>
</div>
 
<div class="header" align="center" >
<div class="top">

<p>Last Activity</p>
</div>

<form action="" method="post">

</br></br></br></br></br></br></br>


<input type="submit"  id="product_code_num" name="submit" value="SHOW">
<?php
	error_reporting (E_ALL^E_NOTICE);
     $conn = mysqli_connect("localhost","root","","cs_2001") or die("unsucessful");
     if(isset($_POST['submit'])){
		 
	 $s="SELECT NAME,EMAIL,TIME_STAMP FROM login WHERE TYPE='ADMIN' ";
	 $result=mysqli_query($conn,$s);
	 if (!($result) || mysqli_num_rows($result)==0){
	 echo "<script>alert('No Records!')</script>";
	 }
	 else{
	    
        
		echo "<br><br><br><br><br><b style='color:black'>No.of records:". mysqli_num_rows($result);
		echo "<table  border=2 style='background-color:#F8F8FF;' >";
		echo "</b>";
        for($fld=0; $fld < mysqli_num_fields($result); $fld++){
	        $f=mysqli_fetch_field_direct($result,$fld);
	        $name=$f->name;
	        echo "<th >";
	        echo "&nbsp;&nbsp;".$name; 
	        echo "</th>"; 
		
        }
	    while($row = mysqli_fetch_assoc($result)){
	        echo "<tr>"; 
	        echo "<td >".$row["NAME"]."</td> <td>".$row["EMAIL"]."</td> <td>".$row["TIME_STAMP"]."</td> ";
            echo "</tr>"; 
	    }
	    echo "</table>";
		}
	 }
	 
	 
	 ?>
</form>
</div>
</html>