<?php

    include_once('dbh.inc.php');
	
	//getting values from the form
	$code = $_POST['code'];
	$quantity = $_POST['quantity'];
	$md = $_POST['md'];
	$exp = $_POST['exp'];
	$rejected = $_POST['rejected'];
	$retrieved = $_POST['retrieved'];
	
	//checking for errors
	$check = mysqli_query($conn,"SELECT * FROM products WHERE CODE_NO = '$code'");
	$rownum = mysqli_num_rows($check);
	
	if(empty($code) || empty($quantity) || empty($md)|| empty($exp)){
		    header('location:../main/enter2.php?error_msg=empty'); 	
	}elseif($rownum == 0){
			header('location:../main/enter2.php?error_msg=code_doesnot_exist');	
	}elseif(is_numeric($quantity) == 0 ){
			header('location:../main/enter2.php?error_msg=quantity_number');	
	}elseif(is_numeric($rejected) == 0 ){
			header('location:../main/enter2.php?error_msg=rejected_number');	
    }elseif(is_numeric($retrieved) == 0){
			header('location:../main/enter2.php?error_msg=retrieved_number');
    }else{
		
		//recognizing the month of the date entered as the manufacturing date
		$mon = date('m',strtotime($md));
		
        if ($mon == 01){
			 //checking if there is a similar entry with the same code and the manufacturing date
			 $check2 = mysqli_query($conn,"SELECT * FROM jan WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 //entering the details to january
				 $sql = "INSERT INTO jan (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM jan WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 //checking the query
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
	         
	    }elseif ($mon == 2){
			 $check2 = mysqli_query($conn,"SELECT * FROM feb WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO feb (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM feb WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
	   }elseif ($mon == 3){
			 $check2 = mysqli_query($conn,"SELECT * FROM mar WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO mar (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM mar WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
        }elseif ($mon == 4){
			 $check2 = mysqli_query($conn,"SELECT * FROM apr WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO apr (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM apr WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
        }elseif ($mon == 5){
			 $check2 = mysqli_query($conn,"SELECT * FROM may WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO may (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM may WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
       }elseif ($mon == 6){
			 $check2 = mysqli_query($conn,"SELECT * FROM jun WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO jun (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM jun WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
       }elseif ($mon == 7){
			 $check2 = mysqli_query($conn,"SELECT * FROM jul WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO jul (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM jul WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
       }elseif ($mon == 8){
			 $check2 = mysqli_query($conn,"SELECT * FROM aug WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO aug (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM aug WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
        }elseif ($mon == 9){
			 $check2 = mysqli_query($conn,"SELECT * FROM sep WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO sep (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM sep WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
       }elseif ($mon == 10){
			 $check2 = mysqli_query($conn,"SELECT * FROM oct WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO oct (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM oct WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
       }elseif ($mon == 11){
			 $check2 = mysqli_query($conn,"SELECT * FROM nov WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO nov (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected','$retrieved',
					 ($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM nov WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
		
	    }else{
			 $check2 = mysqli_query($conn,"SELECT * FROM de WHERE CODE_NO = '$code' AND MF ='$md'");
	         $entryrows = mysqli_num_rows($check2);
			 if($entryrows > 0){
				 header('location:../main/enter2.php?error_msg=entry_exsists');
			 }else{
				 $sql = "INSERT INTO de (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     SELECT '$code','$quantity','$md','$exp','$rejected',
					 '$retrieved',($quantity-$rejected-$retrieved)+(SUM(QUANTITY)-SUM(REJECTED)-SUM(RETRIEVED)) FROM de WHERE CODE_NO ='$code';";
                 $result= mysqli_query($conn, $sql);
				 if(!($result)){
					echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter2.php';</script>"; 
				 }else{
                    echo "<script type='text/javascript'>alert('SUCCESSFULLY ENTERED');window.location='../main/enter2.php';</script>";
			     }
				 mysqli_close($conn);
			 }
           }
}
?>  