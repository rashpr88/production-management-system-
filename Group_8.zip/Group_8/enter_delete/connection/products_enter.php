<?php

    include_once('dbh.inc.php');
	
	//getting values from the form
	
	$name = $_POST['name'];
	$type = $_POST['type'];
	$code = $_POST['code'];
	$volume = $_POST['volume'];
	$unit = $_POST['unit'];
    
    //checking for errors
	
	$check = mysqli_query($conn,"SELECT * FROM products WHERE CODE_NO = '$code'");
	$rownum = mysqli_num_rows($check);
	if(empty($name) || empty($type) || empty($code)){
		header('location:../main/enter1.php?error_msg=empty'); 
	}elseif(!preg_match(('/^[A-Z]{3}[0-9]{3}$/'),$code)){
			header('location:../main/enter1.php?error_msg=pattern');	
	}elseif($rownum > 0){
			header('location:../main/enter1.php?error_msg=code_exists');
		
	}elseif(is_numeric($volume) == 0){
			header('location:../main/enter1.php?error_msg=number');
	}else{
		
		//entering the product
		$sql = "INSERT INTO products (CODE_NO, NAME, TYPE, VOLUME)
                        VALUES('$code','$name','$type','$volume$unit');";

        $result=mysqli_query($conn, $sql);
		
		
		//entering a null entry to january
		
		$sql1 = "INSERT INTO jan (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result1=mysqli_query($conn, $sql1);
		
	     
		
		//entering a null entry to january to february
		
		$sql2 = "INSERT INTO feb (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result2=mysqli_query($conn, $sql2);
		
		//entering a null entry  to march
		
		$sql3 = "INSERT INTO mar (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result3=mysqli_query($conn, $sql3);
		
		//entering a null entry  to april
		
		$sql4 = "INSERT INTO apr (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result4=mysqli_query($conn, $sql4);
		
		//entering a null entry  to may
		
		$sql5 = "INSERT INTO may (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result5=mysqli_query($conn, $sql5);
		
		//entering a null entry  to june
		
		$sql6 = "INSERT INTO jun (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result6=mysqli_query($conn, $sql6);
		
		//entering a null entry  to july
		
		$sql7 = "INSERT INTO jul (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result7=mysqli_query($conn, $sql7);
		
		//entering a null entry  to august
		
		$sql8 = "INSERT INTO aug (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result8=mysqli_query($conn, $sql8);
		
		//entering a null entry  to september
		
		$sql9 = "INSERT INTO sep (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result9=mysqli_query($conn, $sql9);
		
		//entering a null entry  to october
		
		$sql10 = "INSERT INTO oct (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result10=mysqli_query($conn, $sql10);
		
	    //entering a null entry  to november
		
		$sql11 = "INSERT INTO nov (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result11=mysqli_query($conn, $sql11);

        //entering a null entry  to december
		
		$sql12 = "INSERT INTO de (CODE_NO,QUANTITY,MF,EXP,REJECTED,RETRIEVED,IN_STOCK)
                     VALUES ('$code','0','2018-01-01','2018-01-01','0','0','0');";
		$result12=mysqli_query($conn, $sql12);

		//checking if there is  a failed query
		
		if(!($result) || !($result1) || !($result2) || !($result3) || !($result4) || !($result5) || !($result6) || !($result7) || !($result8)
		|| !($result9) || !($result10) || !($result11) || !($result12) ){
			echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/enter1.php';</script>"; 
	    }else{
		    echo "<script type='text/javascript'>alert('PRODUCT $code ENTERED SUCCESSFULLY');window.location='../main/enter1.php';</script>";
        }
	    mysqli_close($conn);
		
				 
		
		
	}
        
    
	

?>
