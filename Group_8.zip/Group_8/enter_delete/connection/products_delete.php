<?php

    include_once('dbh.inc.php');
	
	//getting values from the form
	
	$code =$_POST['code1'];
	
//checking for errors
$check = mysqli_query($conn,"SELECT * FROM products WHERE CODE_NO = '$code'");
$rownum = mysqli_num_rows($check);
if(empty($code)){
	$error_msg['name'] = "empty";
	header('location:../main/delete.php?error_msg=empty');
}elseif($rownum <= 0){
	header('location:../main/delete.php?error_msg=code_doesnot_exist');
}else{
	
	 //deleting the product
	 
	$sql = "DELETE FROM products WHERE CODE_NO = '$code';";
	$result = mysqli_query($conn, $sql);
	
    //deleting january records
	
    $sql1 = "DELETE FROM jan WHERE CODE_NO = '$code';";
    $result1 = mysqli_query($conn, $sql1);
	
	//deleting february records
	
    $sql2 = "DELETE FROM feb WHERE CODE_NO = '$code';";
    $result2 = mysqli_query($conn, $sql2);
	
	//deleting march records
	
    $sql3 = "DELETE FROM mar WHERE CODE_NO = '$code';";
    $result3 = mysqli_query($conn, $sql3);
	
	//deleting april records
	
    $sql4 = "DELETE FROM apr WHERE CODE_NO = '$code';";
    $result4 = mysqli_query($conn, $sql4);
	
	//deleting may records
	
    $sql5 = "DELETE FROM may WHERE CODE_NO = '$code';";
    $result5 = mysqli_query($conn, $sql5);
	
	//deleting june records
	
    $sql6 = "DELETE FROM jun WHERE CODE_NO = '$code';";
    $result6 = mysqli_query($conn, $sql6);
	
	//deleting july records
	
    $sql7 = "DELETE FROM jul WHERE CODE_NO = '$code';";
    $result7 = mysqli_query($conn, $sql7);
	
	//deleting august records
	
    $sql8 = "DELETE FROM aug WHERE CODE_NO = '$code';";
    $result8 = mysqli_query($conn, $sql8);
	
	//deleting september records
	
    $sql9 = "DELETE FROM sep WHERE CODE_NO = '$code';";
    $result9 = mysqli_query($conn, $sql9);
	
	//deleting october records
	
    $sql10 = "DELETE FROM oct WHERE CODE_NO = '$code';";
    $result10 = mysqli_query($conn, $sql10);
	
	//deleting november records
	
    $sql11 = "DELETE FROM nov WHERE CODE_NO = '$code';";
    $result11 = mysqli_query($conn, $sql11);
	
	//deleting december records
	
    $sql12 = "DELETE FROM de WHERE CODE_NO = '$code';";
    $result12 = mysqli_query($conn, $sql12);
	
	//checking if there is  a failed query
	
	if(!($result) || !($result1)|| !($result2)|| !($result3) || !($result4) || !($result5) || !($result6) || !($result7) || !($result8)
		|| !($result9) || !($result10) || !($result11) || !($result12) ){
		echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
	}else{
		echo "<script type='text/javascript'>alert('PRODUCT $code DELETED SUCCESSFULLY');window.location='../main/delete.php';</script>"; 
	}

	mysqli_close($conn);
    
}


?>
