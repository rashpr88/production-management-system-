<?php

    include_once('dbh.inc.php');
	
	//getting values from the form
	
	$md = $_POST['md'];
	$code = $_POST['code2'];

$check = mysqli_query($conn,"SELECT * FROM products WHERE CODE_NO = '$code'");
$rownum = mysqli_num_rows($check);

//checking for errors

if(empty($code) || empty($md)){
	header('location:../main/delete.php?error_msg=empty2');
}elseif($rownum == 0){
	header('location:../main/delete.php?error_msg=code_doesnot_exist2');
}elseif($md == '2018-01-01'){
	header('location:../main/delete.php?error_msg=original');	
}else{	

//recognizing the month of the date entered as the manufacturing date
    $mon = date('m',strtotime($md));
    if ($mon == 01){
		//checking if there is an entry with the given code and the manufacturing date
		$check2 = mysqli_query($conn,"SELECT * FROM jan WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			//deleting the entry from january
			$sql = "DELETE FROM jan WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			//checking the query
		    if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
	    
		
		
		
	}elseif ($mon == 2){
		$check2 = mysqli_query($conn,"SELECT * FROM feb WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM feb WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
	}elseif ($mon == 3){
		$check2 = mysqli_query($conn,"SELECT * FROM mar WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM mar WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
    }elseif ($mon == 4){
		$check2 = mysqli_query($conn,"SELECT * FROM apr WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM apr WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
    }elseif ($mon == 5){
		$check2 = mysqli_query($conn,"SELECT * FROM may WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM may WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
    }elseif ($mon == 6){
		$check2 = mysqli_query($conn,"SELECT * FROM jun WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM jun WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn); 
		}
		
    }elseif ($mon == 7){
		$check2 = mysqli_query($conn,"SELECT * FROM jul WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM jul WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
    }elseif ($mon == 8){
		$check2 = mysqli_query($conn,"SELECT * FROM aug WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM aug WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn); 
		}
		
		
    }elseif ($mon == 9){
		$check2 = mysqli_query($conn,"SELECT * FROM sep WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM sep WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
    }elseif ($mon == 10){
		$check2 = mysqli_query($conn,"SELECT * FROM oct WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM oct WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn); 
		}
		
    }elseif ($mon == 11){
		$check2 = mysqli_query($conn,"SELECT * FROM nov WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM nov WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn);	 
		}
		
	}else{
		$check2 = mysqli_query($conn,"SELECT * FROM de WHERE CODE_NO = '$code' AND MF ='$md'");
	    $entryrows = mysqli_num_rows($check2);
	    if($entryrows == 0){
			header('location:../main/delete.php?error_msg=entry_doesnot_exist');	
		}else{
			$sql = "DELETE FROM de WHERE CODE_NO ='$code' AND MF='$md';";
            $result= mysqli_query($conn, $sql);
			if(!($result)){
				echo "<script type='text/javascript'>alert('UNSUCCESSFUL');window.location='../main/delete.php';</script>"; 
			}else{
                 echo "<script type='text/javascript'>alert('SUCCESSFULLY DELETED');window.location='../main/delete.php';</script>";
			}
			mysqli_close($conn); 
		}
	}
}	
?>   

    