﻿
<html>


<head>  
<title>splash</title>

<script type="text/javascript" src="val.js" ></script>

<link rel="stylesheet" type="text/css" href="styles.css">
<style type="text/css">

.container{
    background-image:url("3.png");
	background-size: 1300px 800px;
		  }
</style>

</head>


<body>  

<!--outline-->

<div class=container>

<!--top-->

<div class=top>
<img src="header.png" width="100%" height="20%">
</div> 


<!--navigation-->

<div id="left">
<div id="nav">

<br /><br />

<ul >
 <li><a href="../../home/HomeAdmin.html" id="nav">HOME</a></li>
 <li><a href="../../view_update/p_h/" id="nav">VIEW AND UPDATE</a></li>
 <li><a href="../../access/help.html" id="nav">HELP</a></li>
 <li><a href="../index.html" onclick="return logout()"><p>LOG OUT</p></a></li> 
</ul> 
 <!--log out confirmation-->
 
  <script>
  function logout(){
    var logout=confirm("Are you sure you want to log out?");
      if(logout){
         return true;
        }
      else{
         return false;
        }
    }
  </script>


</div>
</div>

<!--content-->

<div id="content">
<br /><br />

<!--form to enter product details-->

<div class="enter-form">
<form  action="../connection/products_enter.php" method="POST" >

<u><h2>Product Details</h2></u>

<?php

//displaying an error messsage if any field is empty
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "empty"){
		echo"<div style='color:red;'><p>Fields marked by '*' are required!!!</p></div>";
	}
}
?>

<label>CODE NUMBER<span style='color:red;'>*</span></label>
<input type="text" name="code" size="80" placeholder="eg:-AAA000">

<?php

//displaying an error messsage if the code is already entered
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "code_exists"){
		echo"<div style='color:red;'><p>code already exists</p></div>";
	}
}
?>
<?php

//displaying an error messsage if the entered code does not match the required pattern
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "pattern"){
		echo"<div style='color:red;'><p>Enter a code number with 3 uppercase letters and 3 numbers<br />eg:-AAA000</p></div>";
	}
}
?>

<label>NAME OF THE PRODUCT<span style='color:red;'>*</span></label>
<input type="text" name="name" size="80" /></td>


<label>CATEGORY<span style='color:red;'>*</span></label>
<select name=type>
<option selected>Fizzy Drinks</option>
<option>Flavoured Milk</option>
<option>Fruit Juices</option>
</select>


<label>VOLUME<span style='color:red;'>*</span></label>
<label>
<input type="radio" name="unit" value="ml" checked />MILLILITRES(ml)
<input type="radio" name="unit" value="L" />LITRES(L)</label><br />
<input type="text" name="volume" size="80"  />

<?php

//displaying an error messsage if the entered volume  is not a numeric value
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "number"){
		echo"<div style='color:red;'><p>Enter a number as the volume</p></div>";
	}
}
?>

<button type="submit" name="submit">ENTER</button>
<button type="reset" name="cancel">CANCEL</button>

</form>
</div>
<br />

<?php

echo "<div class='formlinks'>
<a style='background-color:darkblue;' href='enter1.php'>ENTER  A  NEW  PRODUCT</a><br />
<a href='enter2.php'>ENTER PRODUCTION DETAILS</a><br />
<a href='delete.php'>DELETE</a><br />
<a href='index.php'>BACK TO MAIN PAGE</a>
</div>";
?>

</div>

<!--footer-->

<div id="footer">

</div>
</div>
</body>   
</html>