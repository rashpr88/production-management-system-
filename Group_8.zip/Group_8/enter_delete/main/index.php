﻿<html>


<head>  
<title>splash</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style type="text/css">


.container{
    background-image:url("3.png");
	background-size: 1400px 800px;
		  }

</style>
</head>


<body>  

<!--outline-->

<div class=container>

<!--top-->

<div class=top>
<img src="header.png" width="100%" height="20%">
</div> 


<!--navigation-->

<div id="left">
<div id="nav">
<br /><br /><br /><br />
<br /><br /><br />

<ul >
<li><a href="../../home/HomeAdmin.html" id="nav">HOME</a></li>
<li><a href="../../view_update/p_h/" id="nav">VIEW AND UPDATE</a></li>
<li><a href="../../access/help.html" id="nav">HELP</a></li>
<li><a href="../../index.html" onclick="return logout()"><p>LOG OUT</p></a></li> 
  <script>
  function logout(){
    var logout=confirm("Are you sure you want to log out?");
      if(logout){
         return true;
        }
      else{
         return false;
        }
    }
  </script>

</ul>

</div>
</div>


<!--content-->
<br /><br /><br /><br /><br /><br />
<div id="content">
<u><h1 style="font-size:41px;">ENTER AND DELETE</h1></u>
<br />


<p style="display:inline-block; font-size:19px; font-type:candara;">
The user will be held liable/responsible for any illegal action,claims,losses,damages,charges and expenses.You are<br /> fully responsible for all activities 
that occur under your account.It is your responsibility to provide true information.
</p>
<br /><br />
<div class="mainp">

<a href='enter1.php'>ENTER</a>
<a href='delete.php'>DELETE</a>

</div>
<br /><br /><br /><br /><br /><br />
<br /><br /><br />

</div>
<!--footer-->

<div id="footer">

</div>


</div> 
</body>   
</html>