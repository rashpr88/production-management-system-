﻿<html>


<head>  
<title>splash</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style type="text/css">

.container{
    background-image:url("3.png");
	background-size: 1300px 800px;
		  }
</style>
</head>


<body>  

<!--outline-->

<div class=container>

<!--top-->

<div class=top>
<img src="header.png" width="100%" height="20%">
</div> 


<!--navigation-->

<div id="left">
<div id="nav">

<br /><br />

<ul >
 <li><a href="../../home/HomeAdmin.html" id="nav">HOME</a></li>
 <li><a href="../../view_update/p_h/" id="nav">VIEW AND UPDATE</a></li>
 <li><a href="../../access/help.html" id="nav">HELP</a></li>
 <li><a href="../index.html" onclick="return logout()"><p>LOG OUT</p></a></li> 
</ul> 

 <!--log out confirmation-->
  <script>
  function logout(){
    var logout=confirm("Are you sure you want to log out?");
      if(logout){
         return true;
        }
      else{
         return false;
        }
    }
  </script>

</div>
</div>

<!--content-->

<div id="content">
<br /><br />

<!--form to delete production details-->

<div class="delete-form2">
<form action="../connection/production_details_delete.php" method="POST">

<u><h2 align="center">Production Details</h2></u>
<br /><br />
<label>CODE NUMBER</label>
<input type="text" name="code2" size="80" placeholder="eg:-AAA000"/>

<?php

//displaying an error messsage if any field is empty
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "empty2"){
		echo"<div style='color:red;'><p>All fields are required</p></div>";
	}
}
?>
<?php

//displaying an error messsage if the entered code does not exist
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "code_doesnot_exist2"){
		echo"<div style='color:red;'><p>Code you entered does not exist</p></div>";
	}
}
?>

<label>DATE OF MANUFACTURE</label>
<input type="date" name="md" size="80" />

<?php

//displaying an error messsage if the entered date is equal to the date given by the developer
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "original"){
		echo"<div style='color:red;'><p>Please check the date you entered</p></div>";
	}
}
?>

<?php

//displaying an error messsage if the requested entry does not exist
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "entry_doesnot_exist"){
		echo"<div style='color:red;'><p>No entry Found</p></div>";
	}
}
?>

<button type="submit" name="submit">DELETE</button>
<button type="reset" name="cancel">CANCEL</button>

</form>
</div>

<!--form to delete product details-->

<div class="delete-form1">
<form action="../connection/products_delete.php" method="POST">

<label><u><h2 align="center">Product details</h2></u></label>

<br /><br />
<label>CODE NUMBER</label>
<input type="text" name="code1" size="80" placeholder="eg:-AAA000" />

<?php

//displaying an error messsage if no code is entered
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "empty"){
		echo"<div style='color:red;'><p>Please enter a code</p></div>";
	}
}
?>
<?php

//displaying an error messsage if the entered code does not exist
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "code_doesnot_exist"){
		echo"<div style='color:red;'><p>Code you entered does not exist</p></div>";
	}
}
?>

<br /><br />
<button type="submit" name="submit">DELETE</button>
<button type="reset" name="cancel">CANCEL</button>
</form>

<br /><br /><br /><br />
</div>

</div>

<?php
echo"
<br />
<div class='detetelinks'>
<a href='enter1.php'>ENTER A PRODUCT</a><br /><br >
<a href='enter2.php'>ENTER PRODUCTION <br /> DETAILS</a><br /><br >
<a href='index.php'>BACK TO MAIN PAGE</a><br /><br /><br /><br />

<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

</div>"
?>


<!--footer-->

<div id="footer">


</div>
</div>
</body>   
</html>