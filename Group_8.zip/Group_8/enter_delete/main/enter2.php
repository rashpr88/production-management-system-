﻿<html>


<head>  
<title>splash</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style type="text/css">

.container{
    background-image:url("3.png");
	background-size: 1300px 900px;
	     }
		 
</style>
</head>


<body>  

<!--outline-->

<div class=container>

<!--top-->

<div class=top>
<img src="header.png" width="100%" height="20%">
</div> 


<!--navigation-->

<div id="left">
<div id="nav">

<br /><br />

<ul>
 <li><a href="../../home/HomeAdmin.html" id="nav">HOME</a></li>
 <li><a href="../../view_update/p_h/" id="nav">VIEW AND UPDATE</a></li>
 <li><a href="../../access/help.html" id="nav">HELP</a></li>
 <li><a href="../index.html" onclick="return logout()"><p>LOG OUT</p></a></li> 
</ul>

<!--log out confirmation-->
  <script>
  function logout(){
    var logout=confirm("Are you sure you want to log out?");
      if(logout){
         return true;
        }
      else{
         return false;
        }
    }
  </script>

</div>
</div>

<!--content-->

<div id="content">
<br /><br />

<!--form to enter daily production details-->

<div class="enter-form">

<form action="../connection/production_details_enter.php" method="POST">

<u><h2>Production Details</h2></u>

<?php

//displaying an error messsage if any of the required fields are empty
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "empty"){
		echo"<div style='color:red;'><p>Fields marked by '*' are required!!!</p></div>";
	}
}
?>
<?php

//displaying an error messsage if there is a similar entry
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "entry_exsists"){
		echo"<div style='color:red;'><p>An entry with a similar date and a code exists</p></div>";
	}
}
?>

<label>CODE NUMBER<span style='color:red;'> *</span></label>
<input type="text" name="code" size="80" placeholder="eg:-AAA000"/>

<?php

//displaying an error messsage if the entered code does not exist as a product
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "code_doesnot_exist"){
		echo"<div style='color:red;'><p>Code number does not exist.Enter the product first.</p></div>";
	}
}
?>

<label>QUANTITY<span style='color:red;'> *</span></label>
<input type="text" name="quantity" size="80" value="0"/>

<?php

//displaying an error messsage if the quantity entered is not a numeric value
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "quantity_number"){
		echo"<div style='color:red;'><p>Enter a number as the quantity</p></div>";
	}
}
?>

<label>DATE OF MANUFACTURE<span style='color:red;'>*</span></label>
<input type="date" name="md" size="80" />

<label>DATE OF EXPIRE<span style='color:red;'> *</span></label>
<input type="date" name="exp" size="80" />

<label>NO.OF REJECTED PRODUCTS<label>
<input type="text" name="rejected" size="80" value="0"/>

<?php

//displaying an error messsage if the rejected amount entered is not a numeric value
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "rejected_number"){
		echo"<div style='color:red;'><p>Enter a number as the no. of rejected products</p></div>";
	}
}
?>

<label>NO.OF RETRIEVED PRODUCTS</label>
<input type="text" name="retrieved" size="80" value="0"/>

<?php

//displaying an error messsage if the retrieved amount entered is not a numeric value
if(isset($_GET['error_msg'])){
	if($_GET['error_msg'] == "retrieved_number"){
		echo"<div style='color:red;'><p>Enter a number as the no. of retrieved products</p></div>";
	}
}
?>

<button type="submit" name="submit">ENTER</button>
<button type="reset" name="cancel">CANCEL</button>

</table>
</form>

</div>
<br />
<?php

echo "<div class='formlinks'>
<a href='enter1.php'>ENTER  A  NEW  PRODUCT</a><br />
<a style='background-color:darkblue;' href='enter2.php'>ENTER PRODUCTION DETAILS</a><br />
<a href='delete.php'>DELETE</a><br />
<a href='index.php'>BACK TO MAIN PAGE</a>
</div>";

?>

</div>

<!--footer-->

<div id="footer">

</div>
</div>
</body>   
</html>